package mx.com.proyecto1.personas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntityServiceClientesV1Application {

	public static void main(String[] args) {
		SpringApplication.run(EntityServiceClientesV1Application.class, args);
	}

}
