package mx.com.proyecto1.personas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntityServiceClientesV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
